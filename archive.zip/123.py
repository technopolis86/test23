import shutil

shutil.copy('123.py', 'a123/123.py')